/*
Write a program to determine whether there is a vector with given size among a list of vectors (unsorted)given to your program as input. (The vector elements and their sizes are all integers).
You may use math.h to use sqrt function to calculate the size of a 2D vector.
The size of a 2D Vector is defined as:
√( x2 + y2) 
For example the size of a vector (3, 4) would be √ (9+16) =5.

The input to your program is the number of vectors to read, the vectors, and then a series of integers as size of the vectors to look for (as key). The program then outputs the original index of the vector or -1 based on whether the vectors contained the input or not.

Example input:
3
8 15 
3 4
5 12
14
17
13

Example output:
-1
0
2

Logic:
The size of the vectors are as follows:
17, 5, 13
There is no vector of size 14, so the output is -1.
17 is the length of the first vector, so index of it (0) is returned.
13 is the length of the third vector, so index of it (2) is returned. 

Requirements:
1. You should use a struct using typedef.


Note:
To compile your program locally, please add the flag -lm to the gcc command:
gcc prog.c -o prog -lm
lm links the math library to your main program.


Bonus:
1. You should use binary search or a modified version of it that accepts an array of your Vectors.
2. You should have the code to sort any array you want to sort in your program.
*/

// NEED TO FIX THE BINARY SEARCH ITS NOT QUITE WORKING PROPERLY. MAYBE NEED TO COMPUTE THE LENGTH IN MAIN. AND DO A BINARY SEARCH FOR EACH INDIVIDUAL INDEX IN THE NEW SIZES ARRAY

#include<stdio.h>
#include<math.h>

typedef struct
{
	int x;
	int y;
} Vector;

int binarySearch(int size, int numToBeSearchedFor, int lengths[], int index){
	int beginning = 0;
	int end = size-1;
	int mid;
	
	while(beginning <= end)
    {
        mid = (beginning+end)/2;
        if(lengths[mid] == numToBeSearchedFor){
            return index;
        }
        else if (lengths[mid] > numToBeSearchedFor)
            end = mid-1;
        else
            beginning = mid+1;
    }
        if(beginning > end)
            return -1;
}

void bubbleSort(int v[], int size){
	int temp;
	int flag = 0;
	for (int i = 0; i < size; i++){
		for(int j = 0; j < size-i-1; j++){
			if(v[j] > v[j+1])
			{
				flag = 1;
				temp = v[j+1];
				v[j+1] = v[j];
				v[j] = temp;
			}
		}
		if(flag == 0)
			return;
	}
}

int main(){
	int numOfVectorsToRead;
    scanf("%d", &numOfVectorsToRead);
    int sizes[numOfVectorsToRead];
	int lengths[numOfVectorsToRead];
	Vector v[numOfVectorsToRead];
    int returnValue;
   
	for(int i = 0; i < numOfVectorsToRead; i++){
		scanf("%d", &v[i].x);
        scanf("%d", &v[i].y);
	}
	for(int j = 0; j < numOfVectorsToRead; j++){
		scanf("%d", &sizes[j]);
        }
	for(int i = 0; i < numOfVectorsToRead; i++){
		int xsquared = (v[i].x * v[i].x);
        int ysquared = (v[i].y * v[i].y);
        lengths[i] = sqrt(xsquared + ysquared);
  	}
	
    for(int i = 0; i < numOfVectorsToRead; i++){
		returnValue = binarySearch(numOfVectorsToRead,lengths[i],sizes,i);
		printf("%d\n", returnValue);
	}
	return 0;
}