package Hortonworks.SparkTutorial;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.SparkConf;
import org.apache.spark.*;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.*;
import scala.Tuple2;

import java.util.Arrays;

public class Project {
    public static void main(String[] args) {

        SparkSession spark = SparkSession.builder().master("local").appName("ofjunk").config("spark.some.config.option", "some-value").getOrCreate();
        spark.sparkContext().setLogLevel("WARN");
        Dataset<Row> data = spark.read().option("header", true).option("inferSchema", true).csv("C:\\Users\\Clocknight\\Documents\\vgsales.csv");
        // This line groups platform by north american sales
        data.groupBy("Platform").sum("NA_Sales").sort("sum(NA_Sales)").show(100);
        // This line groups platform by EU sales
        data.groupBy("Platform").sum("EU_Sales").sort("sum(EU_Sales)").show(100);
        // This line groups platform by Japanese sales
        data.groupBy("Platform").sum("JP_Sales").sort("sum(JP_Sales)").show(100);
        // This line groups genre by north american sales
        data.groupBy("Genre").sum("NA_Sales").sort("sum(NA_Sales)").show(1000);
        // This line groups genre by EU sales
        data.groupBy("Genre").sum("EU_Sales").sort("sum(EU_Sales)").show(1000);
        // This line groups genre by Japanese sales
        data.groupBy("Genre").sum("JP_Sales").sort("sum(JP_Sales)").show(1000);
        // This line groups publisher by north american sales
        data.groupBy("Publisher").sum("NA_Sales").sort("sum(NA_Sales)").show(1000);
        // This line groups publisher by EU sales
        data.groupBy("Publisher").sum("EU_Sales").sort("sum(EU_Sales)").show(1000);
        // This line groups publisher by Japanese sales
        data.groupBy("Publisher").sum("JP_Sales").sort("sum(JP_Sales)").show(1000);
        

    }
    }
